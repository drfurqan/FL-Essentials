#pragma once
#ifndef Fle_Core_h__
#define Fle_Core_h__

/*********************************************************************************
created:	2017/01/28   03:26AM
filename: 	Fle_Core.h
file base:	Fle_Core
file ext:	h
author:		Furqan Ullah (Post-doc, Ph.D.)
website:    http://real3d.pk
CopyRight:	All Rights Reserved

purpose:	Core functionalities of Fle lib.

/**********************************************************************************
FL-ESSENTIALS (FLE) - FLTK Utility Widgets
Copyright (C) 2014-2019 REAL3D

This file and its content is protected by a software license.
You should have received a copy of this license with this file.
If not, please contact Dr. Furqan Ullah immediately:
**********************************************************************************/

#include <FLE/Fle_Export.h>
#include <FL/fl_ask.H>

namespace R3D
{

class FL_ESSENTIALS_EXPORT Fle_Core
{
public:

	enum { LIGHT_COLOR_THEME, DARK_COLOR_THEME	};
	// Description:
	// Function to initialize the FLE and FLTK libraries.
	static void init(int _theme = LIGHT_COLOR_THEME);
	// Description:
	// Function to event loop for the library.
	static int exec();
};

}

#endif // Fle_Core_h__