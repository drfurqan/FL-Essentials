/*********************************************************************************
created:	2017/04/28   04:56PM
filename: 	main.cpp
file base:	main
file ext:	cpp
author:		Furqan Ullah (Post-doc, Ph.D.)
website:    http://real3d.pk
CopyRight:	All Rights Reserved

purpose:	
In this tutorial, following topics are presented with C++ code.
How can we create a 3D renderer engine to render 3D models.
How can we render 3D mesh model using the vertices and faces attributes.
How can we read 3D data (vertices, faces, normals, texture coordinates, colors) from 3D file format which is PLY.
How can we create a Face-Vertex data structure to store the mesh data.
How can we compute the face normal using the vertices and indices information.
How can we render materials in OpenGL.
How can we apply texture mapping in OpenGL.

/**********************************************************************************
FL-ESSENTIALS (FLE) - FLTK Utility Widgets
Copyright (C) 2017 REAL3D

This file and its content is protected by a software license.
You should have received a copy of this license with this file.
If not, please contact Dr. Furqan Ullah immediately:
**********************************************************************************/

#include <FLE/Fle_Core.h>

#include "GLRenderer.h"

using namespace R3D;

int main()
{
	// library initialization with default modes.
	Fle_Core::init();

	// create OpenGL window by specifying width, height and title.
	GLRenderer win(800, 500, "3D Solar System in FLE/OpenGL");
	win.showMaximized();

	// execute the main loop.
	return Fle_Core::exec();
}